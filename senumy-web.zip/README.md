# Senumy Web

Mobile-first React app for Senumy Jailbreak (guest experience), with luxury iOS-style UI.

## Stack

- Vite + React 19 + TypeScript
- Tailwind CSS
- React Router v7

## Commands

- `npm run dev` — start dev server
- `npm run build` — production build (output in `dist/`)
- `npm run preview` — preview production build

## Images

Copy the `img` folder from the guest app (`fr7hfcgxc5gcee/img/`) into `public/img/` so that the logo and card icons resolve. Required paths:

- `public/img/senumylogo/senumy-logo.png`
- `public/img/cardIcons/*` (senipa.png, applejr.webp, ipa-installer.png, etc.)

## Routes

- `/` — Home (card list)
- `/BecomePremiumUser/` — Become premium (donate + registration code)
- `/donate/` — Donate / Senumy info

Valid registration codes redirect to the premium app on the same site and set `localStorage.senumy_premium`.
