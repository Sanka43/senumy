import { type ButtonHTMLAttributes, type ReactNode } from 'react'

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: 'primary' | 'secondary' | 'outline' | 'red'
  children: ReactNode
}

export default function Button({ variant = 'primary', className = '', children, ...props }: ButtonProps) {
  const base = 'min-h-[44px] min-w-[44px] inline-flex items-center justify-center rounded-lg font-bold px-5 transition-opacity active:opacity-80 disabled:opacity-50'
  const variants = {
    primary: 'bg-senumy-blue text-white',
    secondary: 'bg-gradient-to-r from-green-500 to-blue-500 text-white border-2 border-senumy-accent/60',
    outline: 'border-2 border-senumy-accent/60 text-gray-900 bg-transparent',
    red: 'bg-red-500 text-white',
  }
  return (
    <button type="button" className={`${base} ${variants[variant]} ${className}`} {...props}>
      {children}
    </button>
  )
}
