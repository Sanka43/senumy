import { type InputHTMLAttributes, forwardRef } from 'react'

const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(
  ({ className = '', ...props }, ref) => (
    <input
      ref={ref}
      className={`min-h-[44px] w-full rounded-lg border border-gray-300 bg-white px-3 text-base text-gray-900 placeholder-gray-500 focus:border-senumy-accent focus:outline-none focus:ring-1 focus:ring-senumy-accent ${className}`}
      {...props}
    />
  )
)
Input.displayName = 'Input'
export default Input
