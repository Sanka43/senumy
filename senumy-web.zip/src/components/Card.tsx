import { Link } from 'react-router-dom'

type CardProps = {
  icon: string
  title: string
  description: string
  href: string
  external?: boolean
}

const CARD_ICON_SIZE = 60

const getButtonClass =
  'flex h-8 min-w-[64px] shrink-0 items-center justify-center rounded-full bg-gray-100 px-4 text-[13px] font-semibold text-senumy-accent active:bg-gray-200'

export default function Card({ icon, title, description, href, external }: CardProps) {
  return (
    <div className="flex min-h-[70px] items-center gap-3 rounded-xl bg-white p-3 shadow-card">
      <div className="relative h-[60px] w-[60px] shrink-0 overflow-hidden rounded-lg bg-gray-100">
        {icon ? (
          <img
            src={icon}
            alt=""
            width={CARD_ICON_SIZE}
            height={CARD_ICON_SIZE}
            className="h-full w-full object-contain"
            loading="lazy"
            decoding="async"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-gray-400" aria-hidden>
            <PlaceholderIcon />
          </div>
        )}
      </div>
      <div className="min-w-0 flex-1">
        <div className="font-semibold text-gray-900">{title}</div>
        <p className="mt-0.5 line-clamp-3 text-sm text-gray-600">{description}</p>
      </div>
      {external ? (
        <a href={href} target="_blank" rel="noopener noreferrer" className={getButtonClass} aria-label="Open">
          GET
        </a>
      ) : (
        <Link to={href} className={getButtonClass} aria-label="Open">
          GET
        </Link>
      )}
    </div>
  )
}

function PlaceholderIcon() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
      <path d="M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z" />
    </svg>
  )
}
