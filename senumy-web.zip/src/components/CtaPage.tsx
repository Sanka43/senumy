import { Link } from 'react-router-dom'
import Button from './Button'

type CtaPageProps = {
  children: React.ReactNode
}

const SUPPORT_MAIL = 'mailto:premium.help.department@gmail.com?subject=Senumy Support !'

export default function CtaPage({ children }: CtaPageProps) {
  return (
    <div className="px-4 py-6">
      <p className="text-[15px] font-bold leading-relaxed text-gray-900">
        {children}
      </p>
      <div className="mt-6 flex flex-col gap-3">
        <Link to="/BecomePremiumUser/">
          <Button variant="secondary" className="w-full">
            Install Senumy tools - Premium users
          </Button>
        </Link>
        <Link to="/BecomePremiumUser/">
          <Button variant="outline" className="w-full">
            Become a Senumy premium user
          </Button>
        </Link>
        <a href={SUPPORT_MAIL} target="_blank" rel="noopener noreferrer">
          <Button variant="outline" className="w-full">
            Contact Senumy support
          </Button>
        </a>
      </div>
    </div>
  )
}
