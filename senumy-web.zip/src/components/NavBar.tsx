import { useRef, useState, useMemo } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { LOGO_SRC } from '../lib/assets'
import { HOME_CATEGORIES } from '../data/homeCards'
import type { HomeCard } from '../data/homeCards'

type SearchCard = HomeCard & { category: string }

const ALL_CARDS: SearchCard[] = HOME_CATEGORIES.flatMap((cat) =>
  cat.cards.map((card) => ({ ...card, category: cat.title }))
)

function searchByTitle(query: string): SearchCard[] {
  const q = query.trim().toLowerCase()
  if (!q) return []
  return ALL_CARDS.filter((card) => card.title.toLowerCase().includes(q)).slice(0, 10)
}

export default function NavBar() {
  const navigate = useNavigate()
  const [query, setQuery] = useState('')
  const [focused, setFocused] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)
  const dropdownRef = useRef<HTMLDivElement>(null)

  const results = useMemo(() => searchByTitle(query), [query])
  const showDropdown = focused && query.trim().length > 0

  function handleSelect(card: SearchCard) {
    if (card.external) {
      window.open(card.href, '_blank', 'noopener,noreferrer')
    } else {
      navigate(card.href)
    }
    setQuery('')
    setFocused(false)
    inputRef.current?.blur()
  }

  return (
    <header
      className="fixed top-0 left-0 right-0 z-10 flex h-[var(--nav-height)] min-h-[56px] items-center justify-between gap-3 border-b border-gray-200/90 bg-white/80 px-5 backdrop-blur-md"
      style={{ paddingTop: 'max(env(safe-area-inset-top), 8px)' }}
    >
      <Link
        to="/"
        className="flex min-h-[44px] min-w-[44px] shrink items-center justify-start"
        aria-label="Senumy home"
      >
        <img
          src={LOGO_SRC}
          alt="Senumy"
          className="h-[36px] w-auto max-w-[120px] object-contain object-left"
        />
      </Link>

      <div className="relative flex min-w-0 flex-1 max-w-[260px]">
        <input
          ref={inputRef}
          type="search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setFocused(true)}
          onBlur={() => setTimeout(() => setFocused(false), 150)}
          placeholder="Search by app title…"
          className="h-[44px] w-full rounded-full border border-gray-200 bg-gray-50/80 pl-4 pr-11 text-[15px] text-gray-900 placeholder-gray-500 focus:border-senumy-accent focus:bg-white focus:outline-none focus:ring-2 focus:ring-senumy-accent/20"
          aria-label="Search apps by title"
          autoComplete="off"
        />
        <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" aria-hidden>
          <SearchIcon />
        </span>

        {showDropdown && (
          <div
            ref={dropdownRef}
            className="absolute left-0 right-0 top-full z-20 mt-1 max-h-[70vh] overflow-auto rounded-xl border border-gray-200 bg-white py-1 shadow-lg"
          >
            {results.length === 0 ? (
              <p className="px-4 py-3 text-sm text-gray-500">No apps match “{query}”</p>
            ) : (
              <ul className="py-1">
                {results.map((card) => (
                  <li key={`${card.category}-${card.title}`}>
                    <button
                      type="button"
                      onMouseDown={(e) => {
                        e.preventDefault()
                        handleSelect(card)
                      }}
                      className="flex w-full flex-col gap-0.5 px-4 py-2.5 text-left hover:bg-gray-50"
                    >
                      <span className="font-medium text-gray-900">{card.title}</span>
                      <span className="text-xs text-gray-500">{card.category}</span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
      </div>
    </header>
  )
}

function SearchIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="11" cy="11" r="8" />
      <path d="m21 21-4.35-4.35" />
    </svg>
  )
}
