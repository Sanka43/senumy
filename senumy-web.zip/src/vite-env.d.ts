/// <reference types="vite/client" />

declare module '*.png' {
  const src: string
  export default src
}
declare module '*.PNG' {
  const src: string
  export default src
}
declare module '*.webp' {
  const src: string
  export default src
}
declare module '*.jpg' {
  const src: string
  export default src
}
declare module '*.ico' {
  const src: string
  export default src
}
