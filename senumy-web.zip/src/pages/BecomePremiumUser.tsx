import { useState } from 'react'
import Button from '../components/Button'
import Input from '../components/Input'
import { isValidPremiumCode, setPremiumAndRedirect } from '../lib/validation'

const DONATE_URL = 'https://senumy-store.dpdcart.com/cart/add?product_id=243722&method_id=266244'
const INVALID_MSG =
  'You can recieve Update code for any amount of donation to enjoy All features. Please check your email to copy the correct code, Otherwise, please contact the support team.'

export default function BecomePremiumUser() {
  const [code, setCode] = useState('')
  const [message, setMessage] = useState('')

  const handleUpgrade = () => {
    if (isValidPremiumCode(code)) {
      setPremiumAndRedirect()
    } else {
      setMessage(INVALID_MSG)
    }
  }

  return (
    <div className="px-4 py-6">
        <p className="text-[15px] text-senumy-link">
          Senumy is a unique IPA Store that gives you access to premium IPA libraries all in one place.
          You can download hundreds of exclusive IPAs, including jailbreak tools, tweaks, modded games,
          and Double Plus (Mod) apps. With a one-time donation, you get lifetime access — no recurring payments.
        </p>

        <div className="mt-6 flex justify-center">
          <a href={DONATE_URL} target="_blank" rel="noopener noreferrer">
            <Button variant="red">Donate Now</Button>
          </a>
        </div>

        <div className="mt-6 text-black">
          <p className="text-sm">
            After you donate, check your email to find the ‘registration code’ and enter it below.
            Tap Upgrade to become a premium user in the same app — no download or Settings install needed.
          </p>

          <div className="mt-5">
            <Input
              type="text"
              placeholder="Enter registration code"
              value={code}
              onChange={(e) => setCode(e.target.value)}
            />
          </div>

          {message && <p className="mt-3 text-sm text-gray-600">{message}</p>}

          <div className="mt-5 flex justify-center">
            <Button onClick={handleUpgrade}>Upgrade</Button>
          </div>

          <p className="mt-4 text-center">
            <a
              href="mailto:premium.help.department@gmail.com?subject=Senumy Support !"
              className="text-senumy-link underline"
            >
              Contact support
            </a>
          </p>
        </div>
      </div>
  )
}
