import { Link } from 'react-router-dom'
import Button from '../components/Button'

export default function Donate() {
  return (
    <div className="px-4 py-6">
        <p className="text-[15px] font-bold leading-relaxed text-gray-900">
          The best and largest collection of exclusive IPAs for iOS 14 through the latest iOS 26.
          <br /><br />
          Several premium tools that usually cost $10 to $20 are available for free in the Senumy Store.
        </p>

        <div className="mt-6 flex flex-col gap-3">
          <Link to="/BecomePremiumUser/">
            <Button variant="secondary" className="w-full">
              Install Senumy tools - Premium users
            </Button>
          </Link>
          <Link to="/BecomePremiumUser/">
            <Button variant="outline" className="w-full">
              Become a Senumy premium user
            </Button>
          </Link>
          <a
            href="mailto:premium.help.department@gmail.com?subject=Senumy Support !"
            target="_blank"
            rel="noopener noreferrer"
          >
            <Button variant="outline" className="w-full">
              Contact Senumy support
            </Button>
          </a>
        </div>
      </div>
  )
}
