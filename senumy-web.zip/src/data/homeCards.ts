export type HomeCard = {
  icon: string
  title: string
  description: string
  href: string
  external?: boolean
}

export type HomeCategory = {
  title: string
  cards: HomeCard[]
}

export const HOME_CATEGORIES: HomeCategory[] = [
  {
    title: 'IPA Stores',
    cards: [
      { icon: 'senipa.png', title: 'SenIPA', description: 'SenIPA is the exclusive freemium IPA library with a wide variety of IPAs.', href: '/BecomePremiumUser/' },
      { icon: 'applejr.webp', title: 'AppleJr', description: 'AppleJr lets you install tweaked apps on iOS 26, 18, and 17 without jailbreak or PC—just add the DNS profile and sideload IPAs safely.', href: 'https://apps.senumy.com/applejr/applejr.mobileconfig', external: true },
      { icon: 'ipa-installer.png', title: 'IPA Installer', description: 'Install iOS apps instantly from .ipa or .tipa files with IPA Installer fast, simple, and reliable for developers and testers.', href: '/BecomePremiumUser/' },
      { icon: 'maple-ipa.png', title: 'MapleIPAs', description: 'The easiest way to sideload MapleIPAs Store applications on iOS, iPadOS, tvOS, and visionOS.', href: '/BecomePremiumUser/' },
      { icon: 'velixa.png', title: 'Velixa', description: 'The Velixa IPA Library offers an amazing collection of IPA files.', href: '/BecomePremiumUser/' },
      { icon: 'zignee.png', title: 'Zignee', description: 'Exclusive IPA library with unique files unavailable elsewhere.', href: '/BecomePremiumUser/' },
      { icon: 'jbapastore.png', title: 'JBIPAs Store', description: 'JBIPAs Store: Jailbreak IPA Store for iOS 9 – 17.0 Download and install apps easily.', href: '/BecomePremiumUser/' },
    ],
  },
  {
    title: 'Jailbreak Solution',
    cards: [
      { icon: 'redensa.png', title: 'Redensa', description: 'iTerminal-based Jailbreak solution for the latest iOS version.', href: '/BecomePremiumUser/' },
      { icon: 'Palera1n.webp', title: 'Palear1n', description: 'Palera1n online jailbreak tool for iOS/iPadOS 18+ on iPhones and iPads.', href: '/BecomePremiumUser/' },
      { icon: 'NekoJb.png', title: 'NekoJb', description: 'Neko Online Jailbreak supports iOS 18+ to install Cydia, Sileo, and Zebra.', href: '/BecomePremiumUser/' },
      { icon: 'sileemapp.png', title: 'Sileem', description: 'Sileem is a brand new jailbreak app installer for both iPhones and iPads.', href: '/BecomePremiumUser/' },
      { icon: 'zjailbreak.png', title: 'zJailbreak', description: 'Third-party app store that lists jailbreaks and third-party iOS apps.', href: '/BecomePremiumUser/' },
      { icon: 'Unc0verBlack.png', title: 'Unc0ver Black', description: 'A powerful jailbreak for iOS 18+, making it easy to download Dark Cydia.', href: '/BecomePremiumUser/' },
    ],
  },
  {
    title: 'Package Managers',
    cards: [
      { icon: 'cydia2.png', title: 'Cydia2', description: 'Easily install jailbreak apps, tweaks, and themes on the latest iOS versions.', href: '/BecomePremiumUser/' },
      { icon: 'Sileo2.webp', title: 'Sileo2', description: 'Modern package manager for the latest versions of iOS and iPadOS.', href: '/BecomePremiumUser/' },
    ],
  },
  {
    title: 'iOS 26 Demo – Try It Early',
    cards: [
      { icon: 'ios26.png', title: 'iOS 26 Demo', description: 'Apple renames iOS by year—iOS 26 replaces iOS 19 with a futuristic, AI-powered experience.', href: '/BecomePremiumUser/' },
    ],
  },
  {
    title: "Apple's Future AI Apps",
    cards: [
      { icon: 'AppleGPT.PNG', title: 'Apple GPT', description: "Apple's Next-Gen AI Chatbot.", href: '/BecomePremiumUser/' },
      { icon: 'Safari3DX.png', title: 'Safari 3DX', description: "Apple's 3D internet browser.", href: '/BecomePremiumUser/' },
      { icon: 'apple-ai-search.png', title: 'Apple AI Search', description: 'Next-gen intelligent search engine.', href: '/BecomePremiumUser/' },
    ],
  },
  {
    title: 'Game Stores',
    cards: [
      { icon: 'emula.png', title: 'Emula', description: 'Play classic games, without worrying about revokes.', href: '/BecomePremiumUser/' },
    ],
  },
  {
    title: 'Repo Extractor',
    cards: [
      { icon: 'sileem.png', title: 'Sileem Repo Extractor', description: 'A method for extracting repos to install jailbreak apps, themes, system tweaks, and online jailbreaks.', href: '/BecomePremiumUser/' },
      { icon: 'altlist.png', title: 'AltList', description: 'A modern AppList app for adding Repo IPA tweaks and ++ apps.', href: '/BecomePremiumUser/' },
    ],
  },
  {
    title: 'TrollStore IPA Stores',
    cards: [
      { icon: 'quorix.png', title: 'Quorix', description: 'The ultimate source for TrollStore-based tweaks, apps, and themes.', href: '/BecomePremiumUser/' },
      { icon: 'nexara.png', title: 'Nexara', description: "Nexara's library of KFD IPAs offers amazing apps and tweaks.", href: '/BecomePremiumUser/' },
      { icon: 'trollstore.png', title: 'TrollApps', description: 'An alternative to TrollStore, this subreddit shares non-piracy open-source apps.', href: '/BecomePremiumUser/' },
    ],
  },
  {
    title: 'Third-party app Stores',
    cards: [
      { icon: 'tutupro.png', title: 'TutuPro', description: 'An old IPA library with a large collection of IPAs, still popular today.', href: '/BecomePremiumUser/' },
      { icon: 'panda_helper.png', title: 'Panda Helper', description: 'A top-rated third-party app store and Cydia alternative.', href: '/BecomePremiumUser/' },
      { icon: 'iosninja.webp', title: 'iOS Ninja', description: 'Download iOS Jailbreak, Tweaks, and Apps.', href: '/BecomePremiumUser/' },
      { icon: 'iosgods.webp', title: 'iOSGods', description: 'Experience the ultimate access to tweaks and customized apps.', href: '/BecomePremiumUser/' },
      { icon: 'appvalley.webp', title: 'App Valley', description: 'Tweaked apps No Jailbreak - Get Tweaks Apps For Free iOS.', href: '/BecomePremiumUser/' },
    ],
  },
  {
    title: 'Entertainment',
    cards: [
      { icon: 'tvnow.png', title: 'TVNow', description: 'Watch shows, movies, and live streams anytime on your iPhone or iPad.', href: '/BecomePremiumUser/' },
    ],
  },
  {
    title: 'Shortcuts Tweaks',
    cards: [
      { icon: 'apple_intelligence.png', title: 'Apple Intelligence', description: 'Enable apple intelligence on any unsupported iPhone or iPad.', href: '/BecomePremiumUser/' },
      { icon: 'glance.webp', title: 'Glance', description: 'Add more Lock Screen power to iOS with Glance.', href: '/BecomePremiumUser/' },
      { icon: 'classicls.jpg', title: 'ClassicLS', description: 'iOS 6 style Lock Screen for modern iOS.', href: '/BecomePremiumUser/' },
      { icon: 'home_screen_creator.jpg', title: 'HomeScreen Creator', description: 'Design an Overlay Image for Your Home Screen Wallpaers.', href: '/BecomePremiumUser/' },
      { icon: 'vertiblur.jpg', title: 'Vertiblur', description: 'Blur half of your wallpaper on your Lock Screen & Home Screen.', href: '/BecomePremiumUser/' },
      { icon: 'wetr.jpg', title: 'Wetr', description: 'Rain or Shine, Update Your Lockscreen with Stunning Live Weather.', href: '/BecomePremiumUser/' },
      { icon: 'waltz.jpg', title: 'Waltz', description: 'This shortcut lets you automate switching between your installed wallpapers.', href: '/BecomePremiumUser/' },
      { icon: 'accessible.jpg', title: 'Accessible', description: 'iOS 18+ Filesystem Viewer & Extractor.', href: '/BecomePremiumUser/' },
    ],
  },
  {
    title: 'Utilities Stores',
    cards: [
      { icon: 'adguard-dns.png', title: 'AdGuard DNS', description: 'Free Ad & Tracker Blocker.', href: '/BecomePremiumUser/' },
      { icon: 'ipainstaller.webp', title: 'IPA Installer', description: 'Install an iPA from a link, directly on your device.', href: '/BecomePremiumUser/' },
      { icon: 'iconfig.webp', title: 'iConfig', description: 'A mobileconfig generator for iPhone & iPad.', href: '/BecomePremiumUser/' },
      { icon: 'ideviceinfo.webp', title: 'iDevice Info', description: 'Retrieve information about your iPhone, iPad, and more.', href: '/BecomePremiumUser/' },
    ],
  },
  {
    title: 'Customize Themes and more',
    cards: [
      { icon: 'ela.png', title: 'Ela themes', description: 'Handpicked the best theme collection for iOS 16/17 running iPhones and iPads.', href: '/BecomePremiumUser/' },
      { icon: 'Android-on-iOS.png', title: 'Android on iOS', description: 'Run Android apps and experience Android features on your iOS device with ease!', href: '/BecomePremiumUser/' },
      { icon: 'ryOS_favicon.ico', title: 'ryOS', description: 'Use ryOS Macintosh to experience classic macOS features on iPhone and iPad. No Mac required — everything runs in one app.', href: '/BecomePremiumUser/' },
    ],
  },
]
