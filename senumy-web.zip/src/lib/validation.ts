const VALID_CODES = ['SN2345', 'sn345', 'MX2367', 'NH1359'];

export const PREMIUM_APP_URL = '/prytexdmifgdv7um/';

export function isValidPremiumCode(code: string): boolean {
  const trimmed = code.trim()
  return VALID_CODES.some((c) => c.toLowerCase() === trimmed.toLowerCase())
}

export function isPremiumUser(): boolean {
  try {
    return localStorage.getItem('senumy_premium') === '1'
  } catch {
    return false
  }
}

export function setPremiumAndRedirect(): void {
  try {
    localStorage.setItem('senumy_premium', '1')
  } catch {
    /* ignore */
  }
  window.location.href = PREMIUM_APP_URL
}
